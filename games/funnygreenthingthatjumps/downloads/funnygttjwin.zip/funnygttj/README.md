# Funny Green Thing that Jumps

flappy bird but worse

![image](./assets/fbplayer.png)

![image](./assets/cloud.png)
![image](./assets/cloud.png)
![image](./assets/cloud.png)
![image](./assets/cloud.png)